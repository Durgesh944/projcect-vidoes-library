

export function UserRegister(){
   return(
     <div>
        <h3>Register User</h3>
     </div>
   )
}