
export interface AdminContract
{
    UserId:string;
    Password:string;
}