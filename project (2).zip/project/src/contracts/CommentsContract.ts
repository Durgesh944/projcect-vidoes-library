
export interface CommentsContract
{
    CommentId:number;
    Description:string;
    VideoId:number;
}