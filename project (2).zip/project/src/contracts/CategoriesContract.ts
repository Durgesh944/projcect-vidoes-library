

export interface CategoriesContract
{
    CategoryId:number;
    CategoryName:string;
}