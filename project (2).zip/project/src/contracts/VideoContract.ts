
export interface VideoContract 
{
    VideoId:number;
    Title:string;
    Url:string;
    Description:string;
    Likes:number;
    Dislikes:number;
    CategoryId:number;
}